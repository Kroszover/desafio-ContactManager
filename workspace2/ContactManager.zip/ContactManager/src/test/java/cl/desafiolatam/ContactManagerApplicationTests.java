package cl.desafiolatam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
